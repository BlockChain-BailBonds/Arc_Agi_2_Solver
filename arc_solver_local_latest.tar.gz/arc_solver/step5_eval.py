# arc_solver/step5_eval.py
from typing import Dict, List
import numpy as np
from arc_solver.step0_utils import to_np
def print_grid(grid: List[List[int]]):
    """Render a small ARC grid as text."""
    for row in grid:
        line = "".join(str(v) for v in row)
        print(line)
    print()
def evaluate_task(task: Dict, preds: List[List[List[int]]]):
    """
    Prints train inputs/outputs and test predictions side by side.
    """
    print("=== TRAIN PAIRS ===")
    for i, pair in enumerate(task["train"]):
        print(f"Train {i}")
        print("Input:")
        print_grid(pair["input"])
        print("Output:")
        print_grid(pair["output"])

    print("=== TEST RESULTS ===")
    for i, test in enumerate(task["test"]):
        print(f"Test {i}")
        print("Input:")
        print_grid(test["input"])
        print("Attempt 1:")
        print_grid(preds[i][0])
        print("Attempt 2:")
        print_grid(preds[i][1])
