from pathlib import Path
import os

# Defaults keep your Termux location. Can be overridden by env vars.
_DEFAULT_HOME = "/data/data/com.termux/files/home"
_WORK = os.environ.get("ARC_WORK_DIR", f"{_DEFAULT_HOME}/arc_solver")
_SUB  = os.environ.get("ARC_SUBMISSION_PATH", f"{_WORK}/submission.json")

WORK = Path(_WORK)
WORK.mkdir(parents=True, exist_ok=True)
SUBMISSION_PATH = Path(_SUB)
